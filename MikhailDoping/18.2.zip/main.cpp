#include <iostream>

using namespace std;

class List
{
   public:
      List(): head(0), tail(0), theCount(0) { }
      virtual ~List() {
          while(head) {
              ListCell *p = head;
              head = p->next;
              delete p;
          }
      }
      void insert(int value);
      void append(int value);
      int is_present(int value) const;
      int is_empty() const { return head == 0; }
      int count() const { return theCount; }
   private:
      class ListCell {
         public:
            ListCell(int value, ListCell *cell = nullptr): val(value), next(cell) {}
            int val;
            ListCell *next;
      };
      ListCell *head;
      ListCell *tail;
      int theCount;
};

void List::insert(int value) {
    ListCell *cell = new ListCell(value, head);
    if (tail == 0)
        tail = cell;
    head = cell;
    ++theCount;
}

void List::append(int value) {
    ListCell *cell = new ListCell(value);
    if (head == 0)
        head = tail = cell;
    else {
        tail->next = cell;
        tail = cell;
    }
    ++theCount;
}

int List::is_present(int value) const {
    const ListCell *p = head;
    while (p != 0 && p->val != value)
        p = p->next;
    return p != 0;
}

int main() {
    List myList;
    int tests;
    
    cout<<"Введите число для проверки: "; cin>>tests;
    
    myList.insert(1);
    myList.insert(2);
    myList.append(3);

    cout << "Is "<< tests<< " present? " << myList.is_present(tests) << endl;
    cout << "Count: " << myList.count();
    return 0;
}

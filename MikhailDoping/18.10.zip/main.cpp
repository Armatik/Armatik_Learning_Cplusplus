#include <iostream>

using namespace std;
template <typename T>
void CoolSwitch(T &a, T &b)
{
    cout << "Изначальное состояние: a= " << a << ", b= " << b << endl;
    T temp = b;
    b = a;
    a = temp;
    cout << "Изменённое состояние: a= " << a << ", b= " << b << endl;
}

int main()
{
    int a = 14; int b = 31;
    CoolSwitch<int>(a, b);
    
    double f = 12.21; double d = 54.12;
    CoolSwitch<double>(d,f);
    

    return 0;
}
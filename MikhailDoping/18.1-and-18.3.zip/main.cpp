#include <iostream>

using namespace std;

template <typename T>
class List
{
public:
    List() : head(nullptr), tail(nullptr), theCount(0) {}
    virtual ~List();
    void insert(T value);
    void append(T value);
    bool is_present(T value) const;
    bool is_empty() const { return head == nullptr; }
    int count() const { return theCount; }
private:
    class ListCell
    {
    public:
        ListCell(T value, ListCell* cell = nullptr) : val(value), next(cell) {}
        T val;
        ListCell* next;
    };
    ListCell* head;
    ListCell* tail;
    int theCount;
};

template <typename T>
List<T>::~List()
{
    ListCell* ptr = head;
    while (ptr != nullptr)
    {
        ListCell* next = ptr->next;
        delete ptr;
        ptr = next;
    }
}

template <typename T>
void List<T>::insert(T value)
{
    ListCell* cell = new ListCell(value, head);
    head = cell;
    if (tail == nullptr)
    {
        tail = cell;
    }
    theCount++;
}

template <typename T>
void List<T>::append(T value)
{
    ListCell* cell = new ListCell(value);
    if (tail != nullptr)
    {
        tail->next = cell;
    }
    tail = cell;
    if (head == nullptr)
    {
        head = cell;
    }
    theCount++;
}

template <typename T>
bool List<T>::is_present(T value) const
{
    ListCell* ptr = head;
    while (ptr != nullptr)
    {
        if (ptr->val == value)
        {
            return true;
        }
        ptr = ptr->next;
    }
    return false;
}


int main()
{
    List<int> intList;

    // добавление элементов в список
    intList.append(10);
    intList.append(20);
    intList.insert(5);
    intList.insert(15);

    

    // проверка наличия элемента в списке
    cout << "Integer list: ";
    int value = 15;
    if (intList.is_present(value))
    {
        cout << value << " is present in the list." << endl;
    }
    else
    {
        cout << value << " is not present in the list." << endl;
    }

    // создание списка строк
    List<string> stringList;

    // добавление элементов в список
    stringList.append("Hello");
    stringList.append("world");
    stringList.insert("My");
    stringList.insert("name");
    
    // проверка наличия элемента в списке
    
    cout << "String list: ";
    
    string str = "world";
    if (stringList.is_present(str))
    {
        cout << "\"" << str << "\" is present in the list." << endl;
    }
    else
    {
        cout << "\"" << str << "\" is not present in the list." << endl;
    }

    return 0;
}